package bgu.spl181.net.impl.UserServiceTextBasedProtocol.Tasks;

public class Request implements Task {
    @Override
    public String run() {
        return  "";
    }
}
