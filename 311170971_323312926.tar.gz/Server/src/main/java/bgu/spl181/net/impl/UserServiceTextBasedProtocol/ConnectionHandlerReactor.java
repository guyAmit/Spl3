package bgu.spl181.net.impl.UserServiceTextBasedProtocol;

import java.io.IOException;

public class ConnectionHandlerReactor implements ConnectionHandler<String> {
    @Override
    public void send(String msg) {

    }

    @Override
    public void close() throws IOException {

    }
}
