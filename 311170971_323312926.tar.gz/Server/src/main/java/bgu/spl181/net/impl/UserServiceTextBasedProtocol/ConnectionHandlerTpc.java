package bgu.spl181.net.impl.UserServiceTextBasedProtocol;

import java.io.IOException;

public class ConnectionHandlerTpc implements ConnectionHandler<String> {

    @Override
    public void close() throws IOException {

    }

    @Override
    public void send(String msg) {

    }
}
